#ifndef ladder_base_namespace_H
#define ladder_base_namespace_H

#define  ladder_base  crypto_scalarmult_curve25519_sandy2x_ladder_base
#define _ladder_base _crypto_scalarmult_curve25519_sandy2x_ladder_base

#endif /* ifndef ladder_base_namespace_H */

